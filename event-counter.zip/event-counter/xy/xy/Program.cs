﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using xy;
using System.Runtime.InteropServices;
using Microsoft.Win32;

public class Form1 : Form       //program.cs
{

                                                //Datentypen festlegen (bzw. Klassen)
    private NotifyIcon notifyIcon1;                     //gibt eine Komponente an, die ein Symbol im Statusbereich erstellt. 
    private ContextMenu contextMenu_1;
    private MenuItem menuItem_Exit, menuItem_anzahlKlicks, menuItem_impressum;
    private IContainer components;                          //Stellt Funktionen für Container bereit. Container sind Objekte, die logisch 0 oder mehr Komponenten enthalten.
    Form_anzahl_mausklicks anzahlklicks;
    RegistryKey reg = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);

    [STAThread]
    static void Main()
    {
        Application.Run(new Form1());           //Erstellt die Form -> unten Content definiert

        
           
}






    public Form1()              //Aufgerufene Form
    {
        reg.SetValue("EventCounter", Application.ExecutablePath.ToString());
        reg.Close();
        this.Activated += new EventHandler(Form1_Activated);            //Verhindert öffnen des Programms am Anfang - Methode unten

 

        this.components = new Container();
        this.contextMenu_1 = new ContextMenu();
        this.menuItem_Exit = new MenuItem();
        this.menuItem_anzahlKlicks = new MenuItem();
        this.menuItem_impressum = new MenuItem();

        this.contextMenu_1.MenuItems.AddRange(
            new MenuItem[] {
                this.menuItem_Exit, this.menuItem_anzahlKlicks, this.menuItem_impressum
                }
            );                                       //Erstelle das Context-Menu mit den Einträgen

        
        this.menuItem_Exit.Index = 0;
        this.menuItem_Exit.Text = "E&xit";
        this.menuItem_Exit.Click += new EventHandler(this.menuItem_Exit_Click);

        this.menuItem_anzahlKlicks.Index = 0;
        this.menuItem_anzahlKlicks.Text = "Programm";
        this.menuItem_anzahlKlicks.Click += new EventHandler(this.methode_anzahlKlicks_Click);       //Definiere Einträge des Context-Menüs -> Index = Position, .Click = Welche Methode bei Click aufgerufen wird

        this.menuItem_impressum.Index = 0;
        this.menuItem_impressum.Text = "About";
        this.menuItem_impressum.Click += new EventHandler(this.methode_impressum_Click);




        this.ClientSize = new Size(292, 266);                               //Größe der Form-Anwendung (statt Designer)
        if (this.WindowState == FormWindowState.Normal)      //WindowState gibt an, ob formulat minimiert, maximiert, normal ist.
        {
            this.WindowState = FormWindowState.Maximized;      //Setze es auf Normal groß -> Größe oben angegeben
        };
        this.Text = "Notify Icon Example";                                   //Titel


        this.notifyIcon1 = new NotifyIcon(this.components);
        notifyIcon1.Icon = new Icon("counter-logo-mk2.ico");             //im Ordner bin/Debug    ||  Icon wird in der Infoleiste und der form angezeigt.
        notifyIcon1.ContextMenu = this.contextMenu_1;            //Bei Rechtsklick auf Icon erscheint das oben definierte context-Menü1


        notifyIcon1.Text = "Event Counter";                 //Hover Effect in der Infoleiste - Definition des angezeigten Textes 
        notifyIcon1.Visible = true;                             //Text wird angezeigt

        notifyIcon1.DoubleClick += new EventHandler(this.notifyIcon1_DoubleClick);      //Bei Doppelklick auf Icon wird Form angezeigt -> Programm geöffnet -> Methode aufgerufen


       anzahlklicks = new Form_anzahl_mausklicks();
        

    }

    
   void Form1_Activated(object sender, EventArgs e)
    {
       this.Hide();                //Verberge Form beim Start v.a. - verhindert auch Icon in der Taskleiste
    }



    private void notifyIcon1_DoubleClick(object Sender, EventArgs e)            //Methode bei Doppelklick auf Icon
    { 

        if (this.WindowState == FormWindowState.Minimized)      //WindowState gibt an, ob formulat minimiert, maximiert, normal ist.
        {
            this.WindowState = FormWindowState.Normal;      //Setze es auf Normal groß -> Größe oben angegeben
        };

        this.Activate();            //Aktiviere (öffne) die Form/Programm
    }




    private void menuItem_Exit_Click(object Sender, EventArgs e)         //Bei Klick auf den Eintrag "Exit" im Context Menü
    {
        this.Close();       //Schließt Programm und somit auch Icon in der Leiste
    }


   
    



    private void methode_anzahlKlicks_Click(object Sender, EventArgs e)         //Bei Klick auf den Eintrag im Context Menü
    {

        
        anzahlklicks.Show();       //oeffnet andere Form, schließt diese und legt den Fokus auf die andere
        anzahlklicks.Focus();
      //  this.Visible = false;

    }


    private void methode_impressum_Click(object Sender, EventArgs e)         //Bei Klick auf den Eintrag im Context Menü
    {
        Form_impressum impress = new Form_impressum();

        impress.Show();       //oeffnet andere Form, schließt diese und legt den Fokus auf die andere
        impress.Focus();
        this.Visible = false;

    }



































    private void InitializeComponent()              //Kein Plan - funktioniert auch ohne
    {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(338, 271);
            this.Name = "Form1";
            this.ResumeLayout(false);


    }

    protected override void Dispose(bool disposing)         //Kein Plan - funktioniert auch ohne
    {
        // Clean up any components being used.
        if (disposing)
            if (components != null)
                components.Dispose();

        base.Dispose(disposing);
    }

}